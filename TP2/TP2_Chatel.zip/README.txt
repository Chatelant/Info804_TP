Question 3-1 : j'ai essayé un truc mais c'est surrement faux donc je verrais grace a la deuxieme
Question 3-2 : Commencé un truc mais compile pas, mis en commentaire